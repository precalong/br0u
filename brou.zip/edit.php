<?php 

$tokenBot ='5582199534:AAFkgaLWTaDUbAkp7Mcoe5sKKTBg68RxvxE';
$tokenBot_visitors = '5582199534:AAFkgaLWTaDUbAkp7Mcoe5sKKTBg68RxvxE';
$chatid ='-844780903';
